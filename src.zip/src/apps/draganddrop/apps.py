from django.apps import AppConfig


class DraganddropConfig(AppConfig):
    name = 'draganddrop'
