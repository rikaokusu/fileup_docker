isp_domain = [
    "ocn\.ne\.jp",
    "so-net\.ne\.jp",
    "biglobe\.ne\.jp",
    "nifty\.com",
    "asahi-net\.or\.jp",
    "wakwak\.com",
    "plala\.or\.jp"
]
