free_domain = [
    "yahoo\.co\.jp",
    "hotmail\.com",
    "hotmail\.co\.jp",
    "ybb\.ne\.jp"
]
