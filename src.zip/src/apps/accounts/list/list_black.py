black_domain = [
    "dropbox\.com",
    "onedrive\.com",
    "googledrive\.com",
    "hothot\.co.jp",
    "hoge\.com",
    "nihon\.com",
    "crosshead.co.jp",
    "och.co.jp"
]
